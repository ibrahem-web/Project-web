package com.ajyal.ajyal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjyalApplicationTests {

	@Test
	void contextLoads() {
	}

}
