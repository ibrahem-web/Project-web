package com.ajyal.ajyal.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ajyal.ajyal.dto.request.PasswordUpdateRequest;
import com.ajyal.ajyal.dto.request.UserUpdateRequest;
import com.ajyal.ajyal.exception.BadRequestException;
import com.ajyal.ajyal.exception.ResourceNotFoundException;
import com.ajyal.ajyal.model.User;
import com.ajyal.ajyal.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    public User getUserById(Long id) {
        return userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }
    
    public User updateUser(Long id, UserUpdateRequest userUpdateRequest) {
        User user = getUserById(id);
        
        if (userUpdateRequest.getFullName() != null) {
            user.setFullName(userUpdateRequest.getFullName());
        }
        
        if (userUpdateRequest.getPhoneNumber() != null) {
            user.setPhoneNumber(userUpdateRequest.getPhoneNumber());
        }
        
        return userRepository.save(user);
    }
    
    public User updatePassword(Long id, PasswordUpdateRequest passwordUpdateRequest) {
        User user = getUserById(id);
        
        // Verify old password
        if (!passwordEncoder.matches(passwordUpdateRequest.getOldPassword(), user.getPassword())) {
            throw new BadRequestException("Old password is incorrect");
        }
        
        // Update password
        user.setPassword(passwordEncoder.encode(passwordUpdateRequest.getNewPassword()));
        
        return userRepository.save(user);
    }
    
    public void updateLastLogin(Long id) {
        User user = getUserById(id);
        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);
    }
}
