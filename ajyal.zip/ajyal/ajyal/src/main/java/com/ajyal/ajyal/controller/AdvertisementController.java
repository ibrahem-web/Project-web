package com.ajyal.ajyal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import jakarta.validation.Valid;
import java.util.List;
import com.ajyal.ajyal.dto.request.AdvertisementRequest;
import com.ajyal.ajyal.model.Advertisement;
import com.ajyal.ajyal.service.AdvertisementService;

@RestController
@RequestMapping("/api/advertisements")
public class AdvertisementController {

    @Autowired
    private AdvertisementService advertisementService;
    
    // Public endpoints
    @GetMapping
    public ResponseEntity<List<Advertisement>> getAllActiveAdvertisements() {
        List<Advertisement> advertisements = advertisementService.getAllActiveAdvertisements();
        return new ResponseEntity<>(advertisements, HttpStatus.OK);
    }
    
    // Admin endpoints
    @GetMapping("/admin")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<Advertisement>> getAllAdvertisements() {
        List<Advertisement> advertisements = advertisementService.getAllAdvertisements();
        return new ResponseEntity<>(advertisements, HttpStatus.OK);
    }
    
    @PostMapping
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Advertisement> createAdvertisement(@Valid @RequestBody AdvertisementRequest advertisementRequest) {
        Advertisement newAdvertisement = advertisementService.createAdvertisement(advertisementRequest);
        return new ResponseEntity<>(newAdvertisement, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Advertisement> updateAdvertisement(@PathVariable Long id, @Valid @RequestBody AdvertisementRequest advertisementRequest) {
        Advertisement updatedAdvertisement = advertisementService.updateAdvertisement(id, advertisementRequest);
        return new ResponseEntity<>(updatedAdvertisement, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<HttpStatus> deleteAdvertisement(@PathVariable Long id) {
        advertisementService.deleteAdvertisement(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @PostMapping("/upload-media")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> uploadAdvertisementMedia(@RequestParam("file") MultipartFile file) {
        String mediaPath = advertisementService.storeAdvertisementMedia(file);
        return new ResponseEntity<>(mediaPath, HttpStatus.OK);
    }
    
    @PutMapping("/{id}/toggle-active")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Advertisement> toggleAdvertisementActive(@PathVariable Long id) {
        Advertisement advertisement = advertisementService.toggleAdvertisementActive(id);
        return new ResponseEntity<>(advertisement, HttpStatus.OK);
    }
}
