package com.ajyal.ajyal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AjyalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AjyalApplication.class, args);
	}

}
