package com.ajyal.ajyal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import jakarta.validation.Valid;
import java.util.List;
import com.ajyal.ajyal.dto.request.AchievementRequest;
import com.ajyal.ajyal.model.Achievement;
import com.ajyal.ajyal.service.AchievementService;
@RestController
@RequestMapping("/api/achievements")
public class AchievementController {

    @Autowired
    private AchievementService achievementService;
    
    // Public endpoints
    @GetMapping
    public ResponseEntity<List<Achievement>> getAllAchievements() {
        List<Achievement> achievements = achievementService.getAllAchievements();
        return new ResponseEntity<>(achievements, HttpStatus.OK);
    }
    
    // Admin endpoints
    @PostMapping
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Achievement> createAchievement(@Valid @RequestBody AchievementRequest achievementRequest) {
        Achievement newAchievement = achievementService.createAchievement(achievementRequest);
        return new ResponseEntity<>(newAchievement, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Achievement> updateAchievement(@PathVariable Long id, @Valid @RequestBody AchievementRequest achievementRequest) {
        Achievement updatedAchievement = achievementService.updateAchievement(id, achievementRequest);
        return new ResponseEntity<>(updatedAchievement, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<HttpStatus> deleteAchievement(@PathVariable Long id) {
        achievementService.deleteAchievement(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @PostMapping("/upload-image")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> uploadAchievementImage(@RequestParam("file") MultipartFile file) {
        String imagePath = achievementService.storeAchievementImage(file);
        return new ResponseEntity<>(imagePath, HttpStatus.OK);
    }
    
    @PutMapping("/reorder")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<Achievement>> reorderAchievements(@RequestBody List<Long> achievementIds) {
        List<Achievement> reorderedAchievements = achievementService.reorderAchievements(achievementIds);
        return new ResponseEntity<>(reorderedAchievements, HttpStatus.OK);
    }
}
