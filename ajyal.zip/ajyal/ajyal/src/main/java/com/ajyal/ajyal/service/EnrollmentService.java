package com.ajyal.ajyal.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ajyal.ajyal.dto.response.EnrollmentResponse;
import com.ajyal.ajyal.exception.BadRequestException;
import com.ajyal.ajyal.exception.ResourceNotFoundException;
import com.ajyal.ajyal.model.Course;
import com.ajyal.ajyal.model.Enrollment;
import com.ajyal.ajyal.model.User;
import com.ajyal.ajyal.repository.CourseRepository;
import com.ajyal.ajyal.repository.EnrollmentRepository;
import com.ajyal.ajyal.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class EnrollmentService {

    @Autowired
    private EnrollmentRepository enrollmentRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CourseRepository courseRepository;
    
    public Enrollment enrollUserInCourse(Long userId, Long courseId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        
        Course course = courseRepository.findById(courseId)
            .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + courseId));
        
        // Check if already enrolled
        if (enrollmentRepository.existsByUserIdAndCourseId(userId, courseId)) {
            throw new BadRequestException("User is already enrolled in this course");
        }
        
        Enrollment enrollment = new Enrollment();
        enrollment.setUser(user);
        enrollment.setCourse(course);
        enrollment.setEnrollmentDate(LocalDateTime.now());
        enrollment.setStatus("ACTIVE");
        enrollment.setNotificationSeen(false);
        
        return enrollmentRepository.save(enrollment);
    }
    
    public List<Course> getUserEnrolledCourses(Long userId) {
        List<Enrollment> enrollments = enrollmentRepository.findByUserIdAndStatus(userId, "ACTIVE");
        return enrollments.stream()
            .map(Enrollment::getCourse)
            .collect(Collectors.toList());
    }
    
    public List<EnrollmentResponse> getAllEnrollmentsWithDetails() {
        List<Enrollment> enrollments = enrollmentRepository.findAll();
        return enrollments.stream().map(enrollment -> {
            EnrollmentResponse response = new EnrollmentResponse();
            response.setId(enrollment.getId());
            response.setUserName(enrollment.getUser().getFullName());
            response.setUserEmail(enrollment.getUser().getEmail());
            response.setUserPhone(enrollment.getUser().getPhoneNumber());
            response.setCourseName(enrollment.getCourse().getName());
            response.setEnrollmentDate(enrollment.getEnrollmentDate());
            response.setStatus(enrollment.getStatus());
            response.setNotificationSeen(enrollment.isNotificationSeen());
            return response;
        }).collect(Collectors.toList());
    }
    
    public void markEnrollmentAsSeen(Long id) {
        Enrollment enrollment = enrollmentRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found with id: " + id));
        
        enrollment.setNotificationSeen(true);
        enrollmentRepository.save(enrollment);
    }
}