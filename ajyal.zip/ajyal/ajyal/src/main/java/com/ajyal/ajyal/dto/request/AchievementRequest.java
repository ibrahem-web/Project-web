package com.ajyal.ajyal.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AchievementRequest {
    @NotBlank
    private String title;
    
    private String description;
    
    private String imagePath;
    
    private Integer displayOrder;
}