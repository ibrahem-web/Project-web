package com.ajyal.ajyal.service;

import com.ajyal.ajyal.dto.request.AchievementRequest;
import com.ajyal.ajyal.exception.ResourceNotFoundException;
import com.ajyal.ajyal.model.Achievement;
import com.ajyal.ajyal.repository.AchievementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.IntStream;

@Service
public class AchievementService {

    @Autowired
    private AchievementRepository achievementRepository;
    
    @Autowired
    private FileStorageService fileStorageService;
    
    public List<Achievement> getAllAchievements() {
        return achievementRepository.findAllByOrderByDisplayOrderAsc();
    }
    
    public Achievement getAchievementById(Long id) {
        return achievementRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Achievement not found with id: " + id));
    }
    
    public Achievement createAchievement(AchievementRequest achievementRequest) {
        Achievement achievement = new Achievement();
        achievement.setTitle(achievementRequest.getTitle());
        achievement.setDescription(achievementRequest.getDescription());
        achievement.setImagePath(achievementRequest.getImagePath());
        achievement.setCreatedAt(LocalDateTime.now());
        
        if (achievementRequest.getDisplayOrder() != null) {
            achievement.setDisplayOrder(achievementRequest.getDisplayOrder());
        } else {
            // Get current max display order and increment by 1
            achievement.setDisplayOrder(getMaxDisplayOrder() + 1);
        }
        
        return achievementRepository.save(achievement);
    }
    
    public Achievement updateAchievement(Long id, AchievementRequest achievementRequest) {
        Achievement achievement = getAchievementById(id);
        
        achievement.setTitle(achievementRequest.getTitle());
        achievement.setDescription(achievementRequest.getDescription());
        
        if (achievementRequest.getImagePath() != null) {
            achievement.setImagePath(achievementRequest.getImagePath());
        }
        
        if (achievementRequest.getDisplayOrder() != null) {
            achievement.setDisplayOrder(achievementRequest.getDisplayOrder());
        }
        
        return achievementRepository.save(achievement);
    }
    
    public void deleteAchievement(Long id) {
        Achievement achievement = getAchievementById(id);
        achievementRepository.delete(achievement);
    }
    
    public String storeAchievementImage(MultipartFile file) {
        return fileStorageService.storeFile(file, "achievements");
    }
    
    public List<Achievement> reorderAchievements(List<Long> achievementIds) {
        List<Achievement> achievements = achievementRepository.findAllById(achievementIds);
        
        IntStream.range(0, achievementIds.size()).forEach(i -> {
            Long id = achievementIds.get(i);
            achievements.stream()
                .filter(a -> a.getId().equals(id))
                .findFirst()
                .ifPresent(a -> a.setDisplayOrder(i + 1));
        });
        
        return achievementRepository.saveAll(achievements);
    }
    
    private Integer getMaxDisplayOrder() {
        return achievementRepository.findAll().stream()
            .map(Achievement::getDisplayOrder)
            .max(Integer::compareTo)
            .orElse(0);
    }
}