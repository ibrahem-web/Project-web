package com.ajyal.ajyal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import jakarta.validation.Valid;
import java.util.List;
import com.ajyal.ajyal.dto.request.EnrollmentRequest;
import com.ajyal.ajyal.dto.response.EnrollmentResponse;
import com.ajyal.ajyal.dto.response.MessageResponse;
import com.ajyal.ajyal.model.Course;
import com.ajyal.ajyal.model.Enrollment;
import com.ajyal.ajyal.security.services.UserDetailsImpl;
import com.ajyal.ajyal.service.EnrollmentService;
import com.ajyal.ajyal.service.NotificationService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
@RestController
@RequestMapping("/api/enrollments")
public class EnrollmentController {

    @Autowired
    private EnrollmentService enrollmentService;
    
    @Autowired
    private NotificationService notificationService;
    
    @PostMapping
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<?> enrollInCourse(@RequestBody EnrollmentRequest enrollmentRequest) {
        // Get current logged-in user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        
        Enrollment enrollment = enrollmentService.enrollUserInCourse(
            userDetails.getId(), 
            enrollmentRequest.getCourseId()
        );
        
        // Create notification for admin
        notificationService.createAdminNotification(
            "New enrollment: " + userDetails.getFullName() + " enrolled in " + enrollment.getCourse().getName(),
            "ENROLLMENT"
        );
        
        return ResponseEntity.ok(new MessageResponse("Enrolled successfully!"));
    }
    
    @GetMapping("/my-courses")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<List<Course>> getMyEnrolledCourses() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        
        List<Course> enrolledCourses = enrollmentService.getUserEnrolledCourses(userDetails.getId());
        return new ResponseEntity<>(enrolledCourses, HttpStatus.OK);
    }
    
    // Admin endpoints
    @GetMapping
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<EnrollmentResponse>> getAllEnrollments() {
        List<EnrollmentResponse> enrollments = enrollmentService.getAllEnrollmentsWithDetails();
        return new ResponseEntity<>(enrollments, HttpStatus.OK);
    }
    
    @PutMapping("/{id}/mark-seen")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> markEnrollmentAsSeen(@PathVariable Long id) {
        enrollmentService.markEnrollmentAsSeen(id);
        return ResponseEntity.ok(new MessageResponse("Enrollment marked as seen"));
    }
}