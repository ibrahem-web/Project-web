package com.ajyal.ajyal.service;

import com.ajyal.ajyal.dto.request.AdvertisementRequest;
import com.ajyal.ajyal.exception.ResourceNotFoundException;
import com.ajyal.ajyal.model.Advertisement;
import com.ajyal.ajyal.repository.AdvertisementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AdvertisementService {

    @Autowired
    private AdvertisementRepository advertisementRepository;
    
    @Autowired
    private FileStorageService fileStorageService;
    
    public List<Advertisement> getAllAdvertisements() {
        return advertisementRepository.findAll();
    }
    
    public List<Advertisement> getAllActiveAdvertisements() {
        return advertisementRepository.findByActiveOrderByCreatedAtDesc(true);
    }
    
    public Advertisement getAdvertisementById(Long id) {
        return advertisementRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Advertisement not found with id: " + id));
    }
    
    public Advertisement createAdvertisement(AdvertisementRequest advertisementRequest) {
        Advertisement advertisement = new Advertisement();
        advertisement.setTitle(advertisementRequest.getTitle());
        advertisement.setDescription(advertisementRequest.getDescription());
        advertisement.setMediaPath(advertisementRequest.getMediaPath());
        advertisement.setCreatedAt(LocalDateTime.now());
        advertisement.setActive(true);
        
        if (advertisementRequest.getDisplayOrder() != null) {
            advertisement.setDisplayOrder(advertisementRequest.getDisplayOrder());
        }
        
        return advertisementRepository.save(advertisement);
    }
    
    public Advertisement updateAdvertisement(Long id, AdvertisementRequest advertisementRequest) {
        Advertisement advertisement = getAdvertisementById(id);
        
        advertisement.setTitle(advertisementRequest.getTitle());
        advertisement.setDescription(advertisementRequest.getDescription());
        
        if (advertisementRequest.getMediaPath() != null) {
            advertisement.setMediaPath(advertisementRequest.getMediaPath());
        }
        
        if (advertisementRequest.getDisplayOrder() != null) {
            advertisement.setDisplayOrder(advertisementRequest.getDisplayOrder());
        }
        
        return advertisementRepository.save(advertisement);
    }
    
    public void deleteAdvertisement(Long id) {
        Advertisement advertisement = getAdvertisementById(id);
        advertisementRepository.delete(advertisement);
    }
    
    public String storeAdvertisementMedia(MultipartFile file) {
        return fileStorageService.storeFile(file, "advertisements");
    }
    
    public Advertisement toggleAdvertisementActive(Long id) {
        Advertisement advertisement = getAdvertisementById(id);
        advertisement.setActive(!advertisement.getActive());
        return advertisementRepository.save(advertisement);
    }
}