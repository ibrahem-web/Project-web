// src/main/java/com/ajyal/ajyal/service/DataInitializer.java
package com.ajyal.ajyal.service;

import com.ajyal.ajyal.model.*;
import com.ajyal.ajyal.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private AchievementRepository achievementRepository;

    @Autowired
    private AdvertisementRepository advertisementRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Only initialize if database is empty
        if (userRepository.count() == 0) {
            initializeUsers();
        }
        if (teacherRepository.count() == 0) {
            initializeTeachers();
        }
        if (courseRepository.count() == 0) {
            initializeCourses();
        }
        if (achievementRepository.count() == 0) {
            initializeAchievements();
        }
        if (advertisementRepository.count() == 0) {
            initializeAdvertisements();
        }
    }

    private void initializeUsers() {
        // Create admin user
        User admin = new User(
            "admin",
            "admin@ajyal.com",
            passwordEncoder.encode("admin123"),
            "System Administrator",
            "+1234567890",
            "ADMIN"
        );
        userRepository.save(admin);

        // Create sample users
        List<User> users = Arrays.asList(
            new User("student1", "student1@example.com", passwordEncoder.encode("password123"), "Ahmed Ali", "+966501234567", "USER"),
            new User("student2", "student2@example.com", passwordEncoder.encode("password123"), "Sara Mohammed", "+966501234568", "USER"),
            new User("student3", "student3@example.com", passwordEncoder.encode("password123"), "Omar Hassan", "+966501234569", "USER"),
            new User("student4", "student4@example.com", passwordEncoder.encode("password123"), "Fatima Abdullah", "+966501234570", "USER"),
            new User("student5", "student5@example.com", passwordEncoder.encode("password123"), "Khalid Ibrahim", "+966501234571", "USER")
        );
        userRepository.saveAll(users);
    }

    private void initializeTeachers() {
        List<Teacher> teachers = Arrays.asList(
            createTeacher("Dr. Ahmed Al-Mansouri", "+966501111111", "Mathematics", "University Level", "/teachers/math_teacher.jpg"),
            createTeacher("Prof. Sarah Johnson", "+966501111112", "English Literature", "High School", "/teachers/image1.jpg"),
            createTeacher("Dr. Mohammed Al-Rashid", "+966501111113", "Physics", "University Level", "/teachers/image2.jpg"),
            createTeacher("Ms. Nadia Hassan", "+966501111114", "Arabic Language", "Middle School", "/teachers/carousel-1.jpg"),
            createTeacher("Dr. Omar Khalil", "+966501111115", "Chemistry", "High School", "/teachers/carousel-2.jpg"),
            createTeacher("Prof. Layla Al-Zahra", "+966501111116", "Biology", "University Level", "/teachers/icon1.png"),
            createTeacher("Mr. Hassan Al-Qasemi", "+966501111117", "Computer Science", "High School", "/teachers/icon2.png"),
            createTeacher("Dr. Amina Farouk", "+966501111118", "History", "Middle School", "/teachers/icon3.png")
        );
        teacherRepository.saveAll(teachers);
    }

    private void initializeCourses() {
        List<Teacher> teachers = teacherRepository.findAll();
        
        List<Course> courses = Arrays.asList(
            createCourse("Advanced Mathematics", "Comprehensive mathematics course covering calculus, algebra, and statistics", "12 weeks", teachers.get(0), "/courses/math_teacher.jpg"),
            createCourse("English Communication Skills", "Improve your English speaking, writing, and comprehension skills", "8 weeks", teachers.get(1), "/courses/image1.jpg"),
            createCourse("Physics Fundamentals", "Introduction to physics concepts and practical applications", "10 weeks", teachers.get(2), "/courses/image2.jpg"),
            createCourse("Arabic Grammar & Literature", "Master Arabic language rules and explore classical literature", "6 weeks", teachers.get(3), "/courses/carousel-1.jpg"),
            createCourse("Organic Chemistry", "Detailed study of organic compounds and reactions", "14 weeks", teachers.get(4), "/courses/carousel-2.jpg"),
            createCourse("Biology & Life Sciences", "Explore the world of living organisms and ecosystems", "12 weeks", teachers.get(5), "/courses/icon1.png"),
            createCourse("Programming with Java", "Learn Java programming from basics to advanced concepts", "16 weeks", teachers.get(6), "/courses/icon2.png"),
            createCourse("World History", "Journey through major historical events and civilizations", "10 weeks", teachers.get(7), "/courses/icon3.png"),
            createCourse("Digital Marketing", "Modern marketing strategies in the digital age", "8 weeks", teachers.get(0), "/courses/icon4.png"),
            createCourse("Graphic Design Basics", "Learn design principles and Adobe Creative Suite", "12 weeks", teachers.get(1), "/courses/pngegg.png")
        );
        courseRepository.saveAll(courses);
    }

    private void initializeAchievements() {
        List<Achievement> achievements = Arrays.asList(
            createAchievement("Outstanding Academic Excellence", "Recognized for maintaining highest GPA for three consecutive semesters", "/achievements/carousel-1.jpg", 1),
            createAchievement("Innovation in Technology", "Developed groundbreaking educational app that serves over 10,000 students", "/achievements/carousel-2.jpg", 2),
            createAchievement("Community Service Award", "Completed 500+ hours of community service in educational programs", "/achievements/image1.jpg", 3),
            createAchievement("Research Publication", "Published 15+ research papers in international educational journals", "/achievements/image2.jpg", 4),
            createAchievement("Student Mentor of the Year", "Guided over 200 students to academic success", "/achievements/math_teacher.jpg", 5),
            createAchievement("Digital Learning Pioneer", "First institution to implement fully digital curriculum", "/achievements/icon1.png", 6),
            createAchievement("International Recognition", "Received UNESCO award for educational excellence", "/achievements/icon2.png", 7),
            createAchievement("Sustainable Education", "Achieved carbon-neutral campus status", "/achievements/icon3.png", 8),
            createAchievement("Alumni Success Network", "95% of graduates employed within 6 months", "/achievements/icon4.png", 9),
            createAchievement("Multilingual Program", "Successfully launched programs in 5 languages", "/achievements/pngegg.png", 10)
        );
        achievementRepository.saveAll(achievements);
    }

    private void initializeAdvertisements() {
        List<Advertisement> advertisements = Arrays.asList(
            createAdvertisement("Summer Intensive Courses", "Join our summer intensive program with 50% discount for early birds!", "/advertisements/carousel-1.jpg", 1),
            createAdvertisement("New Campus Opening", "We're excited to announce the opening of our new state-of-the-art campus!", "/advertisements/carousel-2.jpg", 2),
            createAdvertisement("Scholarship Program", "Apply now for our merit-based scholarship program. Up to 100% tuition coverage!", "/advertisements/image1.jpg", 3),
            createAdvertisement("Online Learning Platform", "Access all courses online with our new interactive learning platform", "/advertisements/image2.jpg", 4),
            createAdvertisement("Expert Guest Lectures", "Attend exclusive lectures by industry experts and thought leaders", "/advertisements/math_teacher.jpg", 5),
            createAdvertisement("Career Development Workshop", "Free career guidance and professional development workshops", "/advertisements/icon1.png", 6),
            createAdvertisement("Student Exchange Program", "Study abroad opportunities with our international partner universities", "/advertisements/icon2.png", 7),
            createAdvertisement("Research Opportunities", "Join cutting-edge research projects with faculty members", "/advertisements/icon3.png", 8),
            createAdvertisement("Alumni Network Event", "Connect with successful alumni at our annual networking event", "/advertisements/icon4.png", 9),
            createAdvertisement("Digital Skills Bootcamp", "Intensive bootcamp for in-demand digital skills", "/advertisements/pngegg.png", 10)
        );
        advertisementRepository.saveAll(advertisements);
    }

    private Teacher createTeacher(String name, String phone, String subject, String level, String imagePath) {
        Teacher teacher = new Teacher();
        teacher.setName(name);
        teacher.setPhoneNumber(phone);
        teacher.setSubject(subject);
        teacher.setLevel(level);
        teacher.setImagePath(imagePath);
        teacher.setCreatedAt(LocalDateTime.now());
        return teacher;
    }

    private Course createCourse(String name, String description, String duration, Teacher teacher, String imagePath) {
        Course course = new Course();
        course.setName(name);
        course.setDescription(description);
        course.setDuration(duration);
        course.setTeacher(teacher);
        course.setImagePath(imagePath);
        course.setCreatedAt(LocalDateTime.now());
        return course;
    }

    private Achievement createAchievement(String title, String description, String imagePath, int displayOrder) {
        Achievement achievement = new Achievement();
        achievement.setTitle(title);
        achievement.setDescription(description);
        achievement.setImagePath(imagePath);
        achievement.setDisplayOrder(displayOrder);
        achievement.setCreatedAt(LocalDateTime.now());
        return achievement;
    }

    private Advertisement createAdvertisement(String title, String description, String mediaPath, int displayOrder) {
        Advertisement advertisement = new Advertisement();
        advertisement.setTitle(title);
        advertisement.setDescription(description);
        advertisement.setMediaPath(mediaPath);
        advertisement.setDisplayOrder(displayOrder);
        advertisement.setActive(true);
        advertisement.setCreatedAt(LocalDateTime.now());
        return advertisement;
    }
}