package com.ajyal.ajyal.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CourseRequest {
    @NotBlank
    private String name;
    
    private String description;
    
    private String duration;
    
    private Long teacherId;
    
    private String imagePath;
}