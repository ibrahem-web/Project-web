package com.ajyal.ajyal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import jakarta.validation.Valid;
import java.util.List;
import com.ajyal.ajyal.dto.request.TeacherRequest;
import com.ajyal.ajyal.model.Teacher;
import com.ajyal.ajyal.service.TeacherService;

@RestController
@RequestMapping("/api/teachers")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;
    
    // Public endpoints
    @GetMapping
    public ResponseEntity<List<Teacher>> getAllTeachers() {
        List<Teacher> teachers = teacherService.getAllTeachers();
        return new ResponseEntity<>(teachers, HttpStatus.OK);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Teacher> getTeacherById(@PathVariable Long id) {
        Teacher teacher = teacherService.getTeacherById(id);
        return new ResponseEntity<>(teacher, HttpStatus.OK);
    }
    
    // Admin endpoints
    @PostMapping
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Teacher> createTeacher(@Valid @RequestBody TeacherRequest teacherRequest) {
        Teacher newTeacher = teacherService.createTeacher(teacherRequest);
        return new ResponseEntity<>(newTeacher, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Teacher> updateTeacher(@PathVariable Long id, @Valid @RequestBody TeacherRequest teacherRequest) {
        Teacher updatedTeacher = teacherService.updateTeacher(id, teacherRequest);
        return new ResponseEntity<>(updatedTeacher, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<HttpStatus> deleteTeacher(@PathVariable Long id) {
        teacherService.deleteTeacher(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @PostMapping("/upload-image")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> uploadTeacherImage(@RequestParam("file") MultipartFile file) {
        String imagePath = teacherService.storeTeacherImage(file);
        return new ResponseEntity<>(imagePath, HttpStatus.OK);
    }
}