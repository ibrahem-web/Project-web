package com.ajyal.ajyal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import jakarta.validation.Valid;
import java.util.List;
import com.ajyal.ajyal.dto.request.CourseRequest;
import com.ajyal.ajyal.model.Course;
import com.ajyal.ajyal.service.CourseService;


@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;
    
    // Public endpoints
    @GetMapping
    public ResponseEntity<List<Course>> getAllCourses() {
        List<Course> courses = courseService.getAllCourses();
        return new ResponseEntity<>(courses, HttpStatus.OK);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Course> getCourseById(@PathVariable Long id) {
        Course course = courseService.getCourseById(id);
        return new ResponseEntity<>(course, HttpStatus.OK);
    }
    
    // Admin endpoints
    @PostMapping
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Course> createCourse(@Valid @RequestBody CourseRequest courseRequest) {
        Course newCourse = courseService.createCourse(courseRequest);
        return new ResponseEntity<>(newCourse, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Course> updateCourse(@PathVariable Long id, @Valid @RequestBody CourseRequest courseRequest) {
        Course updatedCourse = courseService.updateCourse(id, courseRequest);
        return new ResponseEntity<>(updatedCourse, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<HttpStatus> deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @PostMapping("/upload-image")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> uploadCourseImage(@RequestParam("file") MultipartFile file) {
        String imagePath = courseService.storeCourseImage(file);
        return new ResponseEntity<>(imagePath, HttpStatus.OK);
    }
}
