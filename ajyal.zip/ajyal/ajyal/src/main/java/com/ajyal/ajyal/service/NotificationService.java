package com.ajyal.ajyal.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ajyal.ajyal.exception.BadRequestException;
import com.ajyal.ajyal.exception.ResourceNotFoundException;
import com.ajyal.ajyal.exception.UnauthorizedException;
import com.ajyal.ajyal.model.Notification;
import com.ajyal.ajyal.model.User;
import com.ajyal.ajyal.repository.NotificationRepository;
import com.ajyal.ajyal.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public List<Notification> getUserNotifications(Long userId) {
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }
    
    public List<Notification> getAdminNotifications() {
        return notificationRepository.findByUserIdIsNullOrderByCreatedAtDesc();
    }
    
    public void createUserNotification(Long userId, String message, String type) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        
        Notification notification = new Notification();
        notification.setUser(user);
        notification.setMessage(message);
        notification.setType(type);
        notification.setRead(false);
        notification.setCreatedAt(LocalDateTime.now());
        
        notificationRepository.save(notification);
    }
    
    public void createAdminNotification(String message, String type) {
        Notification notification = new Notification();
        notification.setUser(null); // null user means admin notification
        notification.setMessage(message);
        notification.setType(type);
        notification.setRead(false);
        notification.setCreatedAt(LocalDateTime.now());
        
        notificationRepository.save(notification);
    }
    
    public void markNotificationAsRead(Long notificationId, Long userId) {
        Notification notification = notificationRepository.findById(notificationId)
            .orElseThrow(() -> new ResourceNotFoundException("Notification not found with id: " + notificationId));
        
        if (!notification.getUser().getId().equals(userId)) {
            throw new UnauthorizedException("You are not authorized to mark this notification as read");
        }
        
        notification.setRead(true);
        notificationRepository.save(notification);
    }
    
    public void markAdminNotificationAsRead(Long notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
            .orElseThrow(() -> new ResourceNotFoundException("Notification not found with id: " + notificationId));
        
        if (notification.getUser() != null) {
            throw new BadRequestException("This is not an admin notification");
        }
        
        notification.setRead(true);
        notificationRepository.save(notification);
    }
    
    public int getAdminUnreadNotificationCount() {
        return notificationRepository.countByUserIdIsNullAndIsReadIsFalse();
    }
}