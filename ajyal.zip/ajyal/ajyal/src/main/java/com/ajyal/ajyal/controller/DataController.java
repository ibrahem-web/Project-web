// src/main/java/com/ajyal/ajyal/controller/DataController.java
package com.ajyal.ajyal.controller;

import com.ajyal.ajyal.dto.response.MessageResponse;
import com.ajyal.ajyal.service.DataManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/data")
public class DataController {

    @Autowired
    private DataManagementService dataManagementService;

    @PostMapping("/initialize")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> initializeData() {
        dataManagementService.initializeAllData();
        return ResponseEntity.ok(new MessageResponse("Database initialized with dummy data successfully!"));
    }

    @PostMapping("/reset")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> resetData() {
        dataManagementService.resetAllData();
        return ResponseEntity.ok(new MessageResponse("Database reset and reinitialized successfully!"));
    }

    @PostMapping("/initialize-teachers")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> initializeTeachers() {
        dataManagementService.initializeTeachers();
        return ResponseEntity.ok(new MessageResponse("Teachers data initialized successfully!"));
    }

    @PostMapping("/initialize-courses")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> initializeCourses() {
        dataManagementService.initializeCourses();
        return ResponseEntity.ok(new MessageResponse("Courses data initialized successfully!"));
    }

    @PostMapping("/initialize-achievements")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> initializeAchievements() {
        dataManagementService.initializeAchievements();
        return ResponseEntity.ok(new MessageResponse("Achievements data initialized successfully!"));
    }

    @PostMapping("/initialize-advertisements")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> initializeAdvertisements() {
        dataManagementService.initializeAdvertisements();
        return ResponseEntity.ok(new MessageResponse("Advertisements data initialized successfully!"));
    }

    @GetMapping("/status")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> getDataStatus() {
        var status = dataManagementService.getDataStatus();
        return ResponseEntity.ok(status);
    }
}