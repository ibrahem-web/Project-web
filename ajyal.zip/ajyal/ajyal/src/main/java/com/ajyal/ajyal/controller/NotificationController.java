package com.ajyal.ajyal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import jakarta.validation.Valid;
import java.util.List;
import com.ajyal.ajyal.dto.response.MessageResponse;
import com.ajyal.ajyal.model.Notification;
import com.ajyal.ajyal.security.services.UserDetailsImpl;
import com.ajyal.ajyal.service.NotificationService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;
    
    // User endpoints
    @GetMapping("/user")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<List<Notification>> getUserNotifications() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        
        List<Notification> notifications = notificationService.getUserNotifications(userDetails.getId());
        return new ResponseEntity<>(notifications, HttpStatus.OK);
    }
    
    @PutMapping("/user/{id}/mark-read")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<?> markUserNotificationAsRead(@PathVariable Long id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        
        notificationService.markNotificationAsRead(id, userDetails.getId());
        return ResponseEntity.ok(new MessageResponse("Notification marked as read"));
    }
    
    // Admin endpoints
    @GetMapping("/admin")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<Notification>> getAdminNotifications() {
        List<Notification> notifications = notificationService.getAdminNotifications();
        return new ResponseEntity<>(notifications, HttpStatus.OK);
    }
    
    @PutMapping("/admin/{id}/mark-read")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> markAdminNotificationAsRead(@PathVariable Long id) {
        notificationService.markAdminNotificationAsRead(id);
        return ResponseEntity.ok(new MessageResponse("Notification marked as read"));
    }
    
    @GetMapping("/admin/unread-count")
@PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Integer> getAdminUnreadNotificationCount() {
        int count = notificationService.getAdminUnreadNotificationCount();
        return new ResponseEntity<>(count, HttpStatus.OK);
    }
}
