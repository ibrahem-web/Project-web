package com.ajyal.ajyal.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ajyal.ajyal.dto.request.CourseRequest;
import com.ajyal.ajyal.exception.ResourceNotFoundException;
import com.ajyal.ajyal.model.Course;
import com.ajyal.ajyal.model.Teacher;
import com.ajyal.ajyal.repository.CourseRepository;
import com.ajyal.ajyal.repository.TeacherRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;
    
    @Autowired
    private TeacherRepository teacherRepository;
    
    @Autowired
    private FileStorageService fileStorageService;
    
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }
    
    public Course getCourseById(Long id) {
        return courseRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + id));
    }
    
    public Course createCourse(CourseRequest courseRequest) {
        Teacher teacher = null;
        if (courseRequest.getTeacherId() != null) {
            teacher = teacherRepository.findById(courseRequest.getTeacherId())
                .orElseThrow(() -> new ResourceNotFoundException("Teacher not found with id: " + courseRequest.getTeacherId()));
        }
        
        Course course = new Course();
        course.setName(courseRequest.getName());
        course.setDescription(courseRequest.getDescription());
        course.setDuration(courseRequest.getDuration());
        course.setTeacher(teacher);
        course.setImagePath(courseRequest.getImagePath());
        course.setCreatedAt(LocalDateTime.now());
        
        return courseRepository.save(course);
    }
    
    public Course updateCourse(Long id, CourseRequest courseRequest) {
        Course course = getCourseById(id);
        
        Teacher teacher = null;
        if (courseRequest.getTeacherId() != null) {
            teacher = teacherRepository.findById(courseRequest.getTeacherId())
                .orElseThrow(() -> new ResourceNotFoundException("Teacher not found with id: " + courseRequest.getTeacherId()));
        }
        
        course.setName(courseRequest.getName());
        course.setDescription(courseRequest.getDescription());
        course.setDuration(courseRequest.getDuration());
        course.setTeacher(teacher);
        
        if (courseRequest.getImagePath() != null) {
            course.setImagePath(courseRequest.getImagePath());
        }
        
        return courseRepository.save(course);
    }
    
    public void deleteCourse(Long id) {
        Course course = getCourseById(id);
        courseRepository.delete(course);
    }
    
    public String storeCourseImage(MultipartFile file) {
        return fileStorageService.storeFile(file, "courses");
    }
}