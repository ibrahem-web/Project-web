package com.ajyal.ajyal.service;

import com.ajyal.ajyal.dto.request.TeacherRequest;
import com.ajyal.ajyal.exception.ResourceNotFoundException;
import com.ajyal.ajyal.model.Teacher;
import com.ajyal.ajyal.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TeacherService {

    @Autowired
    private TeacherRepository teacherRepository;
    
    @Autowired
    private FileStorageService fileStorageService;
    
    public List<Teacher> getAllTeachers() {
        return teacherRepository.findAll();
    }
    
    public Teacher getTeacherById(Long id) {
        return teacherRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Teacher not found with id: " + id));
    }
    
    public Teacher createTeacher(TeacherRequest teacherRequest) {
        Teacher teacher = new Teacher();
        teacher.setName(teacherRequest.getName());
        teacher.setPhoneNumber(teacherRequest.getPhoneNumber());
        teacher.setSubject(teacherRequest.getSubject());
        teacher.setLevel(teacherRequest.getLevel());
        teacher.setImagePath(teacherRequest.getImagePath());
        teacher.setCreatedAt(LocalDateTime.now());
        
        return teacherRepository.save(teacher);
    }
    
    public Teacher updateTeacher(Long id, TeacherRequest teacherRequest) {
        Teacher teacher = getTeacherById(id);
        
        teacher.setName(teacherRequest.getName());
        teacher.setPhoneNumber(teacherRequest.getPhoneNumber());
        teacher.setSubject(teacherRequest.getSubject());
        teacher.setLevel(teacherRequest.getLevel());
        
        if (teacherRequest.getImagePath() != null) {
            teacher.setImagePath(teacherRequest.getImagePath());
        }
        
        return teacherRepository.save(teacher);
    }
    
    public void deleteTeacher(Long id) {
        Teacher teacher = getTeacherById(id);
        teacherRepository.delete(teacher);
    }
    
    public String storeTeacherImage(MultipartFile file) {
        return fileStorageService.storeFile(file, "teachers");
    }
}